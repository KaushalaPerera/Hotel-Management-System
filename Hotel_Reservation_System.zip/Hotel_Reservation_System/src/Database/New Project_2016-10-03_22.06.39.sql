-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.52-community


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema vivanew
--

CREATE DATABASE IF NOT EXISTS vivanew;
USE vivanew;

--
-- Definition of table `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(45) DEFAULT NULL,
  `action` varchar(45) DEFAULT NULL,
  `time` varchar(45) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `year` varchar(45) DEFAULT NULL,
  `time2` varchar(45) DEFAULT NULL,
  `ipaddress` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `actions`
--

/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` (`id`,`uid`,`action`,`time`,`date`,`year`,`time2`,`ipaddress`) VALUES 
 (2,'46','User Logged Out','14:15','2015-05-13',NULL,NULL,NULL),
 (3,'57','User Of ID 57 Logged In','14:16','2015-05-13',NULL,NULL,NULL),
 (4,'57','Product Was Added To Cart','14:18','2015-05-13',NULL,NULL,NULL),
 (5,'57','Product Removed From The Cart','14:20','2015-05-13',NULL,NULL,NULL),
 (6,'57','Shoe Of ID 40Was Removed From The Cart','14:21','2015-05-13',NULL,NULL,NULL),
 (7,'57','Sale-Product Of ID 4 Was Added To Cart','14:22','2015-05-13',NULL,NULL,NULL),
 (8,'57','Order Was Placed','14:23','2015-05-13',NULL,NULL,NULL),
 (9,'57','Sale-Product Of ID 4 Was Added To Cart','14:26','2015-05-13',NULL,NULL,NULL),
 (10,'57','Order Of Rs.5000 Was Placed','14:26','2015-05-13',NULL,NULL,NULL),
 (11,'57','User Of ID 57 Logged In','14:34','2015-05-13',NULL,NULL,NULL),
 (12,'57','User Of ID 57 Logged In','15:00','2015-05-13',NULL,NULL,NULL),
 (13,'46','User Of ID 46 Logged In','15:09','2015-05-13',NULL,NULL,NULL),
 (14,'46','User Of ID 46 Logged Out','15:10','2015-05-13',NULL,NULL,NULL),
 (15,'57','User Of ID 57 Logged In','15:10','2015-05-13',NULL,NULL,NULL),
 (16,'57','User Of ID 57 Logged In','15:55','2015-05-13',NULL,NULL,NULL),
 (17,'57','User Of ID 57 Logged Out','16:14','2015-05-13',NULL,NULL,NULL),
 (18,'46','User Of ID 46 Logged In','11:06','2015-05-14',NULL,NULL,NULL),
 (19,'46','User Of ID 46 Logged Out','11:06','2015-05-14',NULL,NULL,NULL),
 (20,'46','User Of ID 46 Logged In','11:06','2015-05-14',NULL,NULL,NULL),
 (21,'46','User Of ID 46 Logged In','11:45','2015-05-14',NULL,NULL,NULL),
 (22,'46','User Of ID 46 Logged Out','11:46','2015-05-14',NULL,NULL,NULL),
 (23,'57','User Of ID 57 Logged In','11:46','2015-05-14',NULL,NULL,NULL),
 (24,'57','Product Of ID 40 Was Added To Cart','11:46','2015-05-14',NULL,NULL,NULL),
 (25,'57','Product Of ID 40 Was Added To Cart','11:47','2015-05-14',NULL,NULL,NULL),
 (26,'57','Sale-Product Of ID 38 Was Added To Cart','11:47','2015-05-14',NULL,NULL,NULL),
 (27,'57','Sale-Product Of ID 38 Was Added To Cart','11:47','2015-05-14',NULL,NULL,NULL),
 (28,'57','Sale-Product Of ID 38 Was Added To Cart','11:47','2015-05-14',NULL,NULL,NULL),
 (29,'57','Order Of Rs.7500 Was Placed','11:48','2015-05-14',NULL,NULL,NULL),
 (30,'57','Order Of Rs.1980 Was Placed','11:48','2015-05-14',NULL,NULL,NULL),
 (31,'57','Order Of Rs.4500 Was Placed','11:48','2015-05-14',NULL,NULL,NULL),
 (32,'57','Order Of Rs.4500 Was Placed','11:48','2015-05-14',NULL,NULL,NULL),
 (33,'57','Sale-Product Of ID 4 Was Added To Cart','11:49','2015-05-14',NULL,NULL,NULL),
 (34,'57','User Of ID 57 Logged Out','11:51','2015-05-14',NULL,NULL,NULL),
 (35,'46','User Of ID 46 Logged In','11:51','2015-05-14',NULL,NULL,NULL),
 (36,'57','User Of ID 57 Logged In','11:59','2015-05-14',NULL,NULL,NULL),
 (37,'46','User Of ID 46 Logged Out','12:13','2015-05-14',NULL,NULL,NULL),
 (38,'46','User Of ID 46 Logged In','12:13','2015-05-14',NULL,NULL,NULL),
 (39,'46','User Of ID 46 Logged In','12:53','2015-05-14',NULL,NULL,NULL),
 (40,'57','User Of ID 57 Logged In','12:54','2015-05-14',NULL,NULL,NULL),
 (41,'57','Product Of ID 7 Was Added To Cart','12:54','2015-05-14',NULL,NULL,NULL),
 (42,'57','Shoe Of ID 4 Was Removed From The Cart','12:54','2015-05-14',NULL,NULL,NULL),
 (44,'57','Product Of ID 7 Was Added To Cart','13:00','2015-05-14',NULL,NULL,NULL),
 (45,'57','Cart Product Quantity Updated','13:07','2015-05-14',NULL,NULL,NULL),
 (46,'57','Cart Product Quantity Updated','13:11','2015-05-14',NULL,NULL,NULL),
 (47,'57','Cart Product Quantity Updated','13:12','2015-05-14',NULL,NULL,NULL),
 (48,'57','Cart Product Quantity Updated','13:12','2015-05-14',NULL,NULL,NULL),
 (49,'57','Cart Product Quantity Updated','13:13','2015-05-14',NULL,NULL,NULL),
 (50,'57','Sale-Product Of ID 5 Was Added To Cart','13:17','2015-05-14',NULL,NULL,NULL),
 (51,'57','Cart Product Quantity Updated','13:19','2015-05-14',NULL,NULL,NULL),
 (52,'57','Product Of ID 42 Was Added To Cart','13:25','2015-05-14',NULL,NULL,NULL),
 (53,'57','Cart Product Quantity Updated','13:26','2015-05-14',NULL,NULL,NULL),
 (54,'46','Account Activated For User_ID56','13:31','2015-05-14',NULL,NULL,NULL),
 (55,'56','User Of ID 56 Logged In','13:32','2015-05-14',NULL,NULL,NULL),
 (56,'56','Product Of ID 5 Was Added To Cart','13:33','2015-05-14',NULL,NULL,NULL),
 (57,'56','Product Of ID 42 Was Added To Cart','13:35','2015-05-14',NULL,NULL,NULL),
 (58,'56','Shoe Of ID 5 Was Removed From The Cart','13:35','2015-05-14',NULL,NULL,NULL),
 (59,'56','Cart Product Quantity Updated','13:35','2015-05-14',NULL,NULL,NULL),
 (60,'57','Order Of Rs.47500 Was Placed','13:36','2015-05-14',NULL,NULL,NULL),
 (61,'57','Order Of Rs.40000 Was Placed','13:36','2015-05-14',NULL,NULL,NULL),
 (62,'57','Order Of Rs.22500 Was Placed','13:36','2015-05-14',NULL,NULL,NULL),
 (63,'57','User Of ID 57 Logged In','15:17','2015-05-14',NULL,NULL,NULL),
 (64,'57','Sale-Product Of ID 4 Was Added To Cart','15:17','2015-05-14',NULL,NULL,NULL),
 (65,'57','Cart Product Quantity Updated','15:18','2015-05-14',NULL,NULL,NULL),
 (66,'56','User Of ID 56 Logged In','15:18','2015-05-14',NULL,NULL,NULL),
 (67,'56','Sale-Product Of ID 4 Was Added To Cart','15:19','2015-05-14',NULL,NULL,NULL),
 (68,'56','Shoe Of ID 42 Was Removed From The Cart','15:19','2015-05-14',NULL,NULL,NULL),
 (69,'56','Cart Product Quantity Updated','15:19','2015-05-14',NULL,NULL,NULL),
 (70,'56','Cart Product Quantity Updated','15:19','2015-05-14',NULL,NULL,NULL),
 (71,'56','Cart Product Quantity Updated','15:19','2015-05-14',NULL,NULL,NULL),
 (72,'56','Cart Product Quantity Updated','15:19','2015-05-14',NULL,NULL,NULL),
 (73,'56','Cart Product Quantity Updated','15:19','2015-05-14',NULL,NULL,NULL),
 (74,'57','Order Of Rs.40000 Was Placed','15:20','2015-05-14',NULL,NULL,NULL),
 (75,'56','Sale-Product Of ID 43 Was Added To Cart','15:21','2015-05-14',NULL,NULL,NULL),
 (76,'57','Sale-Product Of ID 43 Was Added To Cart','15:22','2015-05-14',NULL,NULL,NULL),
 (77,'56','Cart Product Quantity Updated','15:22','2015-05-14',NULL,NULL,NULL),
 (78,'57','Cart Product Quantity Updated','15:22','2015-05-14',NULL,NULL,NULL),
 (79,'57','Cart Product Quantity Updated','15:22','2015-05-14',NULL,NULL,NULL),
 (80,'57','Cart Product Quantity Updated','15:22','2015-05-14',NULL,NULL,NULL),
 (81,'56','Order Of Rs.105000 Was Placed','15:23','2015-05-14',NULL,NULL,NULL),
 (82,'57','Shoe Of ID 43 Was Removed From The Cart','15:23','2015-05-14',NULL,NULL,NULL),
 (83,'57','Sale-Product Of ID 6 Was Added To Cart','15:24','2015-05-14',NULL,NULL,NULL),
 (84,'56','Shoe Of ID 4 Was Removed From The Cart','15:24','2015-05-14',NULL,NULL,NULL),
 (85,'56','Sale-Product Of ID 6 Was Added To Cart','15:24','2015-05-14',NULL,NULL,NULL),
 (86,'56','Cart Product Quantity Updated','15:24','2015-05-14',NULL,NULL,NULL),
 (87,'57','Order Of Rs.2500 Was Placed','15:24','2015-05-14',NULL,NULL,NULL),
 (88,'56','Sale-Product Of ID 38 Was Added To Cart','15:33','2015-05-14',NULL,NULL,NULL),
 (89,'56','Order Of Rs.1980 Was Placed','15:33','2015-05-14',NULL,NULL,NULL),
 (90,'56','Sale-Product Of ID 5 Was Added To Cart','15:34','2015-05-14',NULL,NULL,NULL),
 (91,'56','Shoe Of ID 6 Was Removed From The Cart','15:34','2015-05-14',NULL,NULL,NULL),
 (92,'57','Sale-Product Of ID 5 Was Added To Cart','15:34','2015-05-14',NULL,NULL,NULL),
 (93,'57','Cart Product Quantity Updated','15:34','2015-05-14',NULL,NULL,NULL),
 (94,'57','Order Of Rs.60000 Was Placed','15:34','2015-05-14',NULL,NULL,NULL),
 (95,'56','User Of ID 56 Logged Out','15:43','2015-05-14',NULL,NULL,NULL),
 (96,'56','User Of ID 56 Logged In','15:44','2015-05-14',NULL,NULL,NULL),
 (97,'56','Sale-Product Of ID 38 Was Added To Cart','15:44','2015-05-14',NULL,NULL,NULL),
 (98,'56','User Of ID 56 Logged Out','15:44','2015-05-14',NULL,NULL,NULL),
 (99,'56','User Of ID 56 Logged In','15:45','2015-05-14',NULL,NULL,NULL),
 (100,'56','User Of ID 56 Logged Out','15:47','2015-05-14',NULL,NULL,NULL),
 (101,'56','User Of ID 56 Logged In','15:49','2015-05-14',NULL,NULL,NULL),
 (102,'56','User Of ID 56 Logged Out','15:49','2015-05-14',NULL,NULL,NULL),
 (103,'56','User Of ID 56 Logged In','15:53','2015-05-14',NULL,NULL,NULL),
 (104,'56','User Of ID 56 Logged Out','15:57','2015-05-14',NULL,NULL,NULL),
 (105,'56','User Of ID 56 Logged In','15:57','2015-05-14',NULL,NULL,NULL),
 (106,'56','User Of ID 56 Logged Out','16:03','2015-05-14',NULL,NULL,NULL),
 (107,'56','User Of ID 56 Logged In','16:03','2015-05-14',NULL,NULL,NULL),
 (108,'56','User Of ID 56 Logged Out','16:08','2015-05-14',NULL,NULL,NULL),
 (109,'56','User Of ID 56 Logged In','16:08','2015-05-14',NULL,NULL,NULL),
 (110,'56','User Of ID 56 Logged Out','16:08','2015-05-14',NULL,NULL,NULL),
 (111,'56','User Of ID 56 Logged In','16:12','2015-05-14',NULL,NULL,NULL),
 (112,'56','User Of ID 56 Logged Out','16:12','2015-05-14',NULL,NULL,NULL),
 (113,'56','User Of ID 56 Logged In','16:14','2015-05-14',NULL,NULL,NULL),
 (114,'56','User Of ID 56 Logged Out','16:14','2015-05-14',NULL,NULL,NULL),
 (115,'56','User Of ID 56 Logged In','16:14','2015-05-14',NULL,NULL,NULL),
 (116,'56','Order Of Rs.1980 Was Placed','16:15','2015-05-14',NULL,NULL,NULL),
 (117,'56','Order Of Rs.1980 Was Placed','16:15','2015-05-14',NULL,NULL,NULL),
 (118,'56','Order Of Rs.1980 Was Placed','16:15','2015-05-14',NULL,NULL,NULL),
 (119,'56','Order Of Rs.1980 Was Placed','16:15','2015-05-14',NULL,NULL,NULL),
 (120,'56','Order Of Rs.1980 Was Placed','16:15','2015-05-14',NULL,NULL,NULL),
 (121,'56','Order Of Rs.1980 Was Placed','16:15','2015-05-14',NULL,NULL,NULL),
 (122,'56','User Of ID 56 Logged Out','16:15','2015-05-14',NULL,NULL,NULL),
 (123,'56','User Of ID 56 Logged Out','16:15','2015-05-14',NULL,NULL,NULL),
 (124,'56','User Of ID 56 Logged In','16:15','2015-05-14',NULL,NULL,NULL),
 (125,'56','Sale-Product Of ID 6 Was Added To Cart','16:16','2015-05-14',NULL,NULL,NULL),
 (126,'56','User Of ID 56 Logged Out','16:16','2015-05-14',NULL,NULL,NULL),
 (127,'56','User Of ID 56 Logged In','16:20','2015-05-14',NULL,NULL,NULL),
 (128,'56','Order Of Rs.2500 Was Placed','16:20','2015-05-14',NULL,NULL,NULL),
 (129,'56','Sale-Product Of ID 6 Was Added To Cart','16:21','2015-05-14',NULL,NULL,NULL),
 (130,'56','User Of ID 56 Logged Out','16:21','2015-05-14',NULL,NULL,NULL),
 (131,'56','User Of ID 56 Logged In','16:22','2015-05-14',NULL,NULL,NULL),
 (132,'56','User Of ID 56 Logged Out','16:22','2015-05-14',NULL,NULL,NULL),
 (133,'56','User Of ID 56 Logged In','16:23','2015-05-14',NULL,NULL,NULL),
 (134,'56','User Of ID 56 Logged Out','16:25','2015-05-14',NULL,NULL,NULL),
 (135,'46','User Of ID 46 Logged In','17:50','2015-05-14',NULL,NULL,NULL),
 (136,'46','20 Stock Added To PID 4','17:52','2015-05-14',NULL,NULL,NULL),
 (137,'46','User Of ID 46 Logged In','18:05','2015-05-14',NULL,NULL,NULL),
 (138,'46','30 Sale Stock Added To PID 5','18:05','2015-05-14',NULL,NULL,NULL),
 (139,'46','25 Sale Stock Added To PID 43','18:06','2015-05-14',NULL,NULL,NULL),
 (140,'46','10 Stock Added To PID 42','18:06','2015-05-14',NULL,NULL,NULL),
 (141,'46','50 Stock Added To PID 7','18:06','2015-05-14',NULL,NULL,NULL),
 (142,'46','User Of ID 46 Logged In','18:14','2015-05-14',NULL,NULL,NULL),
 (143,'46','New Brand Added-()','18:36','2015-05-14',NULL,NULL,NULL),
 (144,'46','New Shoe Added For Sales','18:57','2015-05-14',NULL,NULL,NULL),
 (145,'46','Sale Shoe Was Deleted','18:58','2015-05-14',NULL,NULL,NULL),
 (146,'46','New Shoe Was Added','19:07','2015-05-14',NULL,NULL,NULL),
 (147,'46','Shoe Was Deleted','19:07','2015-05-14',NULL,NULL,NULL),
 (148,'56','User Of ID 56 Logged In','21:58','2015-06-04',NULL,NULL,NULL),
 (149,'56','Product Of ID 7 Was Added To Cart','21:58','2015-06-04',NULL,NULL,NULL),
 (150,'56','Cart Product Quantity Updated','21:58','2015-06-04',NULL,NULL,NULL),
 (151,'56','Product Of ID 7 Was Added To Cart','21:59','2015-06-04',NULL,NULL,NULL),
 (152,'56','Cart Product Quantity Updated','21:59','2015-06-04',NULL,NULL,NULL),
 (153,'56','Cart Product Quantity Updated','21:59','2015-06-04',NULL,NULL,NULL),
 (154,'56','Product Of ID 7 Was Added To Cart','21:59','2015-06-04',NULL,NULL,NULL),
 (155,'56','Shoe Of ID 5 Was Removed From The Cart','21:59','2015-06-04',NULL,NULL,NULL),
 (156,'56','Shoe Of ID 6 Was Removed From The Cart','21:59','2015-06-04',NULL,NULL,NULL),
 (157,'56','Shoe Of ID 7 Was Removed From The Cart','21:59','2015-06-04',NULL,NULL,NULL),
 (158,'56','Shoe Of ID 7 Was Removed From The Cart','22:00','2015-06-04',NULL,NULL,NULL),
 (159,'56','Product Of ID 39 Was Added To Cart','22:00','2015-06-04',NULL,NULL,NULL),
 (160,'56','Product Of ID 7 Was Added To Cart','22:00','2015-06-04',NULL,NULL,NULL),
 (161,'56','Shoe Of ID 39 Was Removed From The Cart','22:00','2015-06-04',NULL,NULL,NULL),
 (162,'56','Shoe Of ID 7 Was Removed From The Cart','22:00','2015-06-04',NULL,NULL,NULL),
 (163,'56','User Of ID 56 Logged Out','22:00','2015-06-04',NULL,NULL,NULL),
 (164,'46','User Of ID 46 Logged In','22:00','2015-06-04',NULL,NULL,NULL),
 (165,'46','User Of ID 46 Logged In','09:28','2015-06-05',NULL,NULL,NULL),
 (166,'46','User Of ID 46 Logged Out','09:30','2015-06-05',NULL,NULL,NULL);
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;


--
-- Definition of table `ask_a_question`
--

DROP TABLE IF EXISTS `ask_a_question`;
CREATE TABLE `ask_a_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `FN` varchar(45) NOT NULL,
  `LN` varchar(45) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `Question` varchar(500) NOT NULL DEFAULT '0',
  `Answer` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ask_a_question`
--

/*!40000 ALTER TABLE `ask_a_question` DISABLE KEYS */;
INSERT INTO `ask_a_question` (`id`,`FN`,`LN`,`Email`,`Question`,`Answer`) VALUES 
 (1,'Kaushala','Perera','kaushalaprabodana@gmail.com','How Can We Make Payments?','You Can Make Payments By Using  Your Credit Card and On Delivery'),
 (2,'Tharindu','Thiwanka','TharinduThiwanka@gmail.com','How Can We Pay By Credit Card?',''),
 (13,'Sanka','Perera','Sankaperera@yahoo.com','What Is Your Return Policy?','');
/*!40000 ALTER TABLE `ask_a_question` ENABLE KEYS */;


--
-- Definition of table `brand`
--

DROP TABLE IF EXISTS `brand`;
CREATE TABLE `brand` (
  `idbrand` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idbrand`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand`
--

/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
INSERT INTO `brand` (`idbrand`,`brand`) VALUES 
 (1,'NICCO'),
 (2,'MACLEEN'),
 (3,'');
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;


--
-- Definition of table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `idCart` int(11) NOT NULL AUTO_INCREMENT,
  `shoe_count` int(11) DEFAULT NULL,
  `total_amount` int(10) unsigned DEFAULT NULL,
  `date_time` timestamp NULL DEFAULT NULL,
  `User_Login_idUser_Login` int(11) NOT NULL,
  `shoe_size` varchar(45) NOT NULL,
  `uid` varchar(45) NOT NULL,
  PRIMARY KEY (`idCart`),
  KEY `fk_Cart_User_Login1` (`User_Login_idUser_Login`),
  CONSTRAINT `fk_Cart_User_Login1` FOREIGN KEY (`User_Login_idUser_Login`) REFERENCES `user_login` (`idUser_Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart`
--

/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;


--
-- Definition of table `cart2`
--

DROP TABLE IF EXISTS `cart2`;
CREATE TABLE `cart2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` varchar(45) DEFAULT NULL,
  `uid` varchar(45) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quantity` int(10) unsigned DEFAULT NULL,
  `size` varchar(45) DEFAULT NULL,
  `up` int(10) unsigned DEFAULT NULL,
  `total` int(10) unsigned DEFAULT NULL,
  `is_purchase` varchar(45) DEFAULT NULL,
  `image1` varchar(45) DEFAULT NULL,
  `shoe_name` varchar(45) DEFAULT NULL,
  `category` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart2`
--

/*!40000 ALTER TABLE `cart2` DISABLE KEYS */;
INSERT INTO `cart2` (`id`,`pid`,`uid`,`date`,`quantity`,`size`,`up`,`total`,`is_purchase`,`image1`,`shoe_name`,`category`,`status`) VALUES 
 (232,'39','56','2015-04-19 14:46:36',1,'6',6500,6500,'0','images/1c.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (233,'42','56','2015-04-21 22:15:20',1,'8',2500,2500,'0','images/1h.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (234,'38','57','2015-05-08 14:15:21',1,'7',4500,4500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (235,'38','57','2015-05-08 14:48:55',3,'7',4500,13500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (236,'40','57','2015-05-08 15:09:05',2,'9',7500,15000,'0','images/1g.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (237,'39','57','2015-05-09 11:15:50',1,'6',6500,6500,'0','images/1c.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (240,'40','57','2015-05-09 13:01:11',1,'9',7500,7500,'0','images/1g.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (251,'43','57','2015-05-10 22:29:26',5,'9',6000,30000,'0','images/1a.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (253,'38','57','2015-05-10 23:02:18',7,'7',4500,31500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (254,'38','57','2015-05-10 23:02:24',3,'3',4500,13500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (255,'38','57','2015-05-10 23:07:26',7,'7',4500,31500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (256,'38','57','2015-05-10 23:07:32',3,'3',4500,13500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (257,'42','57','2015-05-12 18:45:41',1,'8',2500,2500,'0','images/1h.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (259,'40','57','2015-05-12 22:22:30',5,'9',7500,37500,'0','images/1g.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (260,'38','57','2015-05-12 22:48:31',1,'8',4500,4500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (261,'4','57','2015-05-12 23:55:03',1,'8',5000,5000,'0','images/1d.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (264,'4','57','2015-05-13 14:22:56',1,'6',5000,5000,'0','images/1d.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (265,'4','57','2015-05-13 14:26:42',1,'6',5000,5000,'0','images/1d.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (266,'40','57','2015-05-14 11:46:59',2,'8',3750,7500,'0','images/1g.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (267,'38','57','2015-05-14 11:47:25',1,'6',1980,1980,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (268,'38','57','2015-05-14 11:47:29',1,'7',4500,4500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (269,'38','57','2015-05-14 11:47:34',1,'8',4500,4500,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (271,'7','57','2015-05-14 12:54:18',5,'8',9500,47500,'0','images/1b.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (272,'5','57','2015-05-14 13:17:14',10,'7',4000,40000,'0','images/1g.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (273,'42','57','2015-05-14 13:25:53',10,'7',2250,22500,'0','images/1h.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (276,'4','57','2015-05-14 15:17:53',8,'6',5000,40000,'0','images/1d.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (278,'43','56','2015-05-14 15:21:54',25,'8',4200,105000,'0','images/1a.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (280,'6','57','2015-05-14 15:24:07',1,'8',2500,2500,'0','images/1e.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (282,'38','56','2015-05-14 15:33:38',1,'6',1980,1980,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (284,'5','57','2015-05-14 15:34:40',15,'7',4000,60000,'0','images/1g.jpg','Men\'s Naturalizer Danya',NULL,'Ordered'),
 (285,'38','56','2015-05-14 15:44:25',1,'7',1980,1980,'0','images/1.jpg','Women\'s Naturalizer Danya',NULL,'Ordered'),
 (286,'6','56','2015-05-14 16:16:02',1,'8',2500,2500,'0','images/1e.jpg','Women\'s Naturalizer Danya',NULL,'Ordered');
/*!40000 ALTER TABLE `cart2` ENABLE KEYS */;


--
-- Definition of table `cart_has_shoes`
--

DROP TABLE IF EXISTS `cart_has_shoes`;
CREATE TABLE `cart_has_shoes` (
  `id_cart_has_shoes` int(11) NOT NULL AUTO_INCREMENT,
  `cart_idCart` int(11) NOT NULL,
  `shoes_idboots` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `is_purchase` varchar(45) DEFAULT NULL,
  `price` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_cart_has_shoes`),
  KEY `fk_cart_has_shoes_shoes1_idx` (`shoes_idboots`),
  KEY `fk_cart_has_shoes_cart1_idx` (`cart_idCart`),
  CONSTRAINT `cart_idCart` FOREIGN KEY (`cart_idCart`) REFERENCES `cart` (`idCart`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cart_has_shoes`
--

/*!40000 ALTER TABLE `cart_has_shoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_has_shoes` ENABLE KEYS */;


--
-- Definition of table `colour`
--

DROP TABLE IF EXISTS `colour`;
CREATE TABLE `colour` (
  `idcolour` int(11) NOT NULL AUTO_INCREMENT,
  `colour` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idcolour`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `colour`
--

/*!40000 ALTER TABLE `colour` DISABLE KEYS */;
INSERT INTO `colour` (`idcolour`,`colour`) VALUES 
 (1,'RED'),
 (2,'WHITE'),
 (3,'BLUE'),
 (4,'BLACK'),
 (5,'PINK'),
 (6,'GREEN'),
 (7,'ORANGE'),
 (8,'GREY'),
 (9,'PURPLE'),
 (10,'BROWN'),
 (11,'YELLOW');
/*!40000 ALTER TABLE `colour` ENABLE KEYS */;


--
-- Definition of table `companymails`
--

DROP TABLE IF EXISTS `companymails`;
CREATE TABLE `companymails` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mail` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companymails`
--

/*!40000 ALTER TABLE `companymails` DISABLE KEYS */;
/*!40000 ALTER TABLE `companymails` ENABLE KEYS */;


--
-- Definition of table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `telephone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `addressno` varchar(45) NOT NULL,
  `address1` varchar(45) NOT NULL,
  `address2` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `idCustomer` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(45) DEFAULT NULL,
  `Last_Name` varchar(45) DEFAULT NULL,
  `Birth_Day` varchar(45) DEFAULT NULL,
  `Address_1` varchar(45) DEFAULT NULL,
  `Address_2` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `Postal_Code` varchar(45) DEFAULT NULL,
  `Username` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `E_Mail` varchar(45) DEFAULT NULL,
  `Telephone` varchar(45) DEFAULT NULL,
  `Payment_Method` varchar(45) DEFAULT NULL,
  `Payment_Acc_Number` varchar(45) DEFAULT NULL,
  `Cart_idCart` int(11) NOT NULL,
  PRIMARY KEY (`idCustomer`),
  KEY `fk_Customer_Cart1` (`Cart_idCart`),
  CONSTRAINT `fk_Customer_Cart1` FOREIGN KEY (`Cart_idCart`) REFERENCES `cart` (`idCart`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `faq`
--

DROP TABLE IF EXISTS `faq`;
CREATE TABLE `faq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(45) NOT NULL,
  `question` varchar(500) NOT NULL DEFAULT '0',
  `answer` varchar(500) NOT NULL DEFAULT '0',
  `category` varchar(500) NOT NULL DEFAULT '0',
  `email` varchar(45) NOT NULL,
  `ordernumber` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faq`
--

/*!40000 ALTER TABLE `faq` DISABLE KEYS */;
INSERT INTO `faq` (`id`,`subject`,`question`,`answer`,`category`,`email`,`ordernumber`) VALUES 
 (1,'A','What is Preferred Shipping?','Preferred Shipping is an upgraded U.S. shipping option that guarantees the first delivery attempt for most packages within 3 to 5 business days of the package being received by the carrier.','a','a',1),
 (2,'B','What are the return shipping costs for an international order?','Return shipping costs vary by country. When you contact our Customer Service Department to request a return and receive your Returns Authorization Number, we\'ll let you know how much you\'ll be...','b','b',2),
 (3,'C','Can I change or cancel my order once it\'s been placed?','Once an order has been placed, we are unable to change any details of the order. However we may be able to cancel your order prior to shipment from our warehouse (once it\'s left our warehouse, we...','c','c',3),
 (4,'D','d1','d2','d','d',4),
 (5,'E','e1','e2','e','e',5),
 (6,'F','f1','f2','f','f',6),
 (7,'G','g1','g2','g','g',7),
 (8,'H','h1','h2','h','h',8);
/*!40000 ALTER TABLE `faq` ENABLE KEYS */;


--
-- Definition of table `gender`
--

DROP TABLE IF EXISTS `gender`;
CREATE TABLE `gender` (
  `idgender` int(11) NOT NULL AUTO_INCREMENT,
  `gender` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idgender`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gender`
--

/*!40000 ALTER TABLE `gender` DISABLE KEYS */;
INSERT INTO `gender` (`idgender`,`gender`) VALUES 
 (1,'Male'),
 (2,'Fe-Male');
/*!40000 ALTER TABLE `gender` ENABLE KEYS */;


--
-- Definition of table `home_image`
--

DROP TABLE IF EXISTS `home_image`;
CREATE TABLE `home_image` (
  `idhome_image` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idhome_image`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `home_image`
--

/*!40000 ALTER TABLE `home_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `home_image` ENABLE KEYS */;


--
-- Definition of table `homebrands`
--

DROP TABLE IF EXISTS `homebrands`;
CREATE TABLE `homebrands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homebrands`
--

/*!40000 ALTER TABLE `homebrands` DISABLE KEYS */;
/*!40000 ALTER TABLE `homebrands` ENABLE KEYS */;


--
-- Definition of table `homesearch`
--

DROP TABLE IF EXISTS `homesearch`;
CREATE TABLE `homesearch` (
  `idhomesearch` int(11) NOT NULL AUTO_INCREMENT,
  `shoeName` varchar(45) DEFAULT NULL,
  `size` varchar(45) DEFAULT NULL,
  `image1` varchar(500) DEFAULT NULL,
  `brand` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `style` varchar(45) DEFAULT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  `color` varchar(45) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `common` varchar(45) DEFAULT NULL,
  `image2` varchar(500) DEFAULT NULL,
  `image3` varchar(500) DEFAULT NULL,
  `image4` varchar(500) DEFAULT NULL,
  `image5` varchar(500) DEFAULT NULL,
  `image6` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`idhomesearch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homesearch`
--

/*!40000 ALTER TABLE `homesearch` DISABLE KEYS */;
/*!40000 ALTER TABLE `homesearch` ENABLE KEYS */;


--
-- Definition of table `homesearch_has_sizes`
--

DROP TABLE IF EXISTS `homesearch_has_sizes`;
CREATE TABLE `homesearch_has_sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homesearch_idhomesearch` int(11) NOT NULL,
  `sizes_idsizes` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_homesearch_has_sizes_sizes1_idx` (`sizes_idsizes`),
  KEY `fk_homesearch_has_sizes_homesearch1_idx` (`homesearch_idhomesearch`),
  CONSTRAINT `fk_homesearch_has_sizes_homesearch1` FOREIGN KEY (`homesearch_idhomesearch`) REFERENCES `homesearch` (`idhomesearch`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_homesearch_has_sizes_sizes1` FOREIGN KEY (`sizes_idsizes`) REFERENCES `sizes` (`idsizes`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `homesearch_has_sizes`
--

/*!40000 ALTER TABLE `homesearch_has_sizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `homesearch_has_sizes` ENABLE KEYS */;


--
-- Definition of table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `idimages` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idimages`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images`
--

/*!40000 ALTER TABLE `images` DISABLE KEYS */;
/*!40000 ALTER TABLE `images` ENABLE KEYS */;


--
-- Definition of table `login_sessions`
--

DROP TABLE IF EXISTS `login_sessions`;
CREATE TABLE `login_sessions` (
  `idLogin_Sessions` int(11) NOT NULL AUTO_INCREMENT,
  `In_Time` varchar(45) DEFAULT NULL,
  `Out_Time` varchar(45) DEFAULT NULL,
  `IP_Address` varchar(45) DEFAULT NULL,
  `User_Login_idUser_Login` int(11) NOT NULL,
  PRIMARY KEY (`idLogin_Sessions`),
  KEY `fk_Login_Sessions_User_Login1` (`User_Login_idUser_Login`),
  CONSTRAINT `fk_Login_Sessions_User_Login1` FOREIGN KEY (`User_Login_idUser_Login`) REFERENCES `user_login` (`idUser_Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_sessions`
--

/*!40000 ALTER TABLE `login_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_sessions` ENABLE KEYS */;


--
-- Definition of table `newarrivals`
--

DROP TABLE IF EXISTS `newarrivals`;
CREATE TABLE `newarrivals` (
  `id` int(11) NOT NULL,
  `shoeName` varchar(45) DEFAULT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `brandname` varchar(45) DEFAULT NULL,
  `image1` varchar(45) DEFAULT NULL,
  `image2` varchar(45) DEFAULT NULL,
  `image3` varchar(45) DEFAULT NULL,
  `image4` varchar(45) DEFAULT NULL,
  `image5` varchar(45) DEFAULT NULL,
  `image6` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `newarrivals`
--

/*!40000 ALTER TABLE `newarrivals` DISABLE KEYS */;
/*!40000 ALTER TABLE `newarrivals` ENABLE KEYS */;


--
-- Definition of table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(45) DEFAULT NULL,
  `pid` varchar(45) DEFAULT NULL,
  `size` varchar(45) DEFAULT NULL,
  `up` varchar(45) DEFAULT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  `paymentmethod` varchar(45) DEFAULT NULL,
  `cardnumber` varchar(45) DEFAULT NULL,
  `cvn` varchar(45) DEFAULT NULL,
  `em` varchar(45) DEFAULT NULL,
  `ey` varchar(45) DEFAULT NULL,
  `address1` varchar(45) DEFAULT NULL,
  `address2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `postalcode` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `status` varchar(45) NOT NULL,
  `date` varchar(100) DEFAULT NULL,
  `time` varchar(45) NOT NULL,
  `month` varchar(45) NOT NULL,
  `year` varchar(45) NOT NULL,
  `date2` varchar(45) NOT NULL,
  `dc` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=487 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`,`uid`,`pid`,`size`,`up`,`quantity`,`paymentmethod`,`cardnumber`,`cvn`,`em`,`ey`,`address1`,`address2`,`city`,`country`,`postalcode`,`email`,`mobile`,`firstname`,`lastname`,`status`,`date`,`time`,`month`,`year`,`date2`,`dc`) VALUES 
 (439,'56','39','6','6500','1','Cash On Delivery','','','-Select-','-Select-','726/E','Kottunna Road','Heiyanthuduwa','Sri Lanka','32025','Kaushalaprabodana@gmail.com','0772207500','Lakmina','Udayangana','Ordered','2015-04-19','15:04','04','2015','19',''),
 (440,'56','42','8','2500','1','Cash On Delivery','','','-Select-','-Select-','726/E','Kottunna Road','Heiyanthuduwa','Sri Lanka','32025','Kaushalaprabodana@gmail.com','0772207500','Lakmina','Udayangana','Ordered','2015-04-21','22:04','04','2015','21',''),
 (441,'57','38','7','4500','1','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Declined','2015-05-08','14:05','05','2015','08',''),
 (442,'57','38','7','4500','3','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Delivered','2015-05-08','14:05','05','2015','08',''),
 (443,'57','40','9','7500','2','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-09','11:05','05','2015','09',''),
 (444,'57','39','6','6500','1','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-09','11:05','05','2015','09',''),
 (447,'57','40','9','7500','1','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-09','13:05','05','2015','09',''),
 (448,'57','38','7','4500','7','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:05','05','2015','10',''),
 (449,'57','42','8','2500','2','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:05','05','2015','10',''),
 (450,'56','42','8','2500','2','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:05','05','2015','10',''),
 (451,'56','43','9','6000','1','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:05','05','2015','10',''),
 (452,'56','4','7','5000','1','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:05','05','2015','10',''),
 (453,'56','43','9','6000','1','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:34','05','2015','10',''),
 (454,'56','43','9','6000','1','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:34','05','2015','10',''),
 (455,'56','43','9','6000','5','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:35','05','2015','10',''),
 (456,'56','43','9','6000','5','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','22:36','05','2015','10',''),
 (457,'57','38','7','4500','7','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','23:02','05','2015','10',''),
 (458,'57','38','3','4500','3','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','23:02','05','2015','10',''),
 (459,'57','38','7','4500','7','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','23:07','05','2015','10',''),
 (460,'57','38','3','4500','3','Cash On Delivery','','','-Select-','-Select-','777/E','Samurdhi Mawatha','Heuyanthuduwa','USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-10','23:07','05','2015','10',''),
 (461,'57','42','8','2500','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-12','21:06','05','2015','12','2545'),
 (462,'57','40','9','7500','5','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-12','23:55','05','2015','12',''),
 (463,'57','38','8','4500','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-12','23:55','05','2015','12',''),
 (464,'57','4','8','5000','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-12','23:55','05','2015','12',''),
 (465,'57','4','6','5000','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-13','14:23','05','2015','13',''),
 (466,'57','4','6','5000','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-13','14:26','05','2015','13',''),
 (467,'57','40','8','3750','2','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Delivered','2015-05-14','11:48','05','2015','14','114'),
 (468,'57','38','6','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','11:48','05','2015','14','114'),
 (469,'57','38','7','4500','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','11:48','05','2015','14','114'),
 (470,'57','38','8','4500','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Delivered','2015-05-14','11:48','05','2015','14','114'),
 (472,'57','7','8','9500','5','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','13:36','05','2015','14','45'),
 (473,'57','5','7','4000','10','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','13:36','05','2015','14','45'),
 (474,'57','42','7','2250','10','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','13:36','05','2015','14','45'),
 (475,'57','4','6','5000','8','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','15:20','05','2015','14',''),
 (476,'56','43','8','4200','25','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','15:23','05','2015','14',''),
 (477,'57','6','8','2500','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','15:24','05','2015','14',''),
 (478,'56','38','6','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','15:33','05','2015','14',''),
 (479,'57','5','7','4000','15','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'USA','32025','Tharindu@gmail.com','0772207500','Tharindu','Thiwanka','Ordered','2015-05-14','15:34','05','2015','14',''),
 (480,'56','38','7','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','16:15','05','2015','14','45'),
 (481,'56','38','7','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','16:15','05','2015','14','45'),
 (482,'56','38','7','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','16:15','05','2015','14','45'),
 (483,'56','38','7','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','16:15','05','2015','14','45'),
 (484,'56','38','7','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','16:15','05','2015','14','45'),
 (485,'56','38','7','1980','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','16:15','05','2015','14','45'),
 (486,'56','6','8','2500','1','Cash On Delivery','','','-Select-','-Select-',NULL,NULL,NULL,'Sri Lanka','32025','AshaniIndrachapa@gmail.com','0772207500','Ashani','Indrachapa','Ordered','2015-05-14','16:20','05','2015','14','45');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;


--
-- Definition of table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `idPurchases` int(11) NOT NULL AUTO_INCREMENT,
  `Time` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `Quantity` varchar(45) DEFAULT NULL,
  `Payment_Method` varchar(45) DEFAULT NULL,
  `Delivery_Address` varchar(45) DEFAULT NULL,
  `Customer_idCustomer` int(11) NOT NULL,
  `Month` varchar(45) DEFAULT NULL,
  `Year` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idPurchases`),
  KEY `fk_Purchases_Customer1` (`Customer_idCustomer`),
  CONSTRAINT `fk_Purchases_Customer1` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `customer` (`idCustomer`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `purchases`
--

/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;


--
-- Definition of table `saleitems`
--

DROP TABLE IF EXISTS `saleitems`;
CREATE TABLE `saleitems` (
  `idshoes` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `sizes_idsizes` int(11) DEFAULT NULL,
  `colour_idcolour` int(11) DEFAULT NULL,
  `style_idstyle` int(11) DEFAULT NULL,
  `brand_idbrand` int(11) DEFAULT NULL,
  `oldprice` int(11) unsigned DEFAULT NULL,
  `newprice` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `gender_idgender` int(11) DEFAULT NULL,
  `common` varchar(45) DEFAULT NULL,
  `image1` varchar(300) DEFAULT NULL,
  `image2` varchar(300) DEFAULT NULL,
  `image3` varchar(300) DEFAULT NULL,
  `image4` varchar(300) DEFAULT NULL,
  `image5` varchar(300) DEFAULT NULL,
  `image6` varchar(300) DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`idshoes`),
  KEY `fk_boots_sizes1_idx` (`sizes_idsizes`),
  KEY `fk_boots_colour1_idx` (`colour_idcolour`),
  KEY `fk_boots_style1_idx` (`style_idstyle`),
  KEY `fk_boots_brand1_idx` (`brand_idbrand`),
  KEY `fk_shoes_gender1_idx` (`gender_idgender`),
  CONSTRAINT `fk_boots_brand10` FOREIGN KEY (`brand_idbrand`) REFERENCES `brand` (`idbrand`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boots_colour10` FOREIGN KEY (`colour_idcolour`) REFERENCES `colour` (`idcolour`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boots_sizes10` FOREIGN KEY (`sizes_idsizes`) REFERENCES `sizes` (`idsizes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boots_style10` FOREIGN KEY (`style_idstyle`) REFERENCES `style` (`idstyle`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_shoes_gender10` FOREIGN KEY (`gender_idgender`) REFERENCES `gender` (`idgender`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saleitems`
--

/*!40000 ALTER TABLE `saleitems` DISABLE KEYS */;
INSERT INTO `saleitems` (`idshoes`,`name`,`sizes_idsizes`,`colour_idcolour`,`style_idstyle`,`brand_idbrand`,`oldprice`,`newprice`,`qty`,`gender_idgender`,`common`,`image1`,`image2`,`image3`,`image4`,`image5`,`image6`,`type`) VALUES 
 (4,'Women\'s Naturalizer Danya',2,3,2,1,6500,5000,20,2,'1','images/1d.jpg','images/2d.jpg','images/3d.jpg','images/4d.jpg','images/5d.jpg','images/6d.jpg','sale'),
 (5,'Men\'s Naturalizer Danya',5,10,3,1,5000,4000,30,1,'1','images/1g.jpg','images/2g.jpg','images/3g.jpg','images/4g.jpg','images/5g.jpg','images/6g.jpg','sale'),
 (6,'Women\'s Naturalizer Danya',4,10,2,2,3500,2500,13,2,'1','images/1e.jpg','images/2e.jpg','images/3e.jpg','images/4e.jpg','images/5e.jpg','images/6e.jpg','sale'),
 (7,'Women\'s Naturalizer Danya',3,10,5,1,8000,9500,50,2,'1','images/1b.jpg','images/2b.jpg','images/3b.jpg','images/4b.jpg','images/5b.jpg','images/6b.jpg','normal'),
 (38,'Women\'s Naturalizer Danya',2,10,1,1,2250,1980,40,2,'1','images/1.jpg','images/2.jpg','images/3.jpg','images/4.jpg','images/5.jpg','images/6.jpg','sale'),
 (39,'Women\'s Naturalizer Danya',1,4,1,2,6500,6500,30,2,'1','images/1c.jpg','images/2c.jpg','images/3c.jpg','images/4c.jpg','images/5c.jpg','images/6c.jpg','normal'),
 (40,'Men\'s Naturalizer Danya',4,10,3,1,7500,3750,18,1,'1','images/1g.jpg','images/2g.jpg','images/3g.jpg','images/4g.jpg','images/5g.jpg','images/6g.jpg','normal'),
 (41,'Women\'s Naturalizer Danya',4,4,1,1,4500,5000,50,1,'1','images/1i.jpg','images/2i.jpg','images/3i.jpg','images/4i.jpg','images/5i.jpg','images/6i.jpg','normal'),
 (42,'Men\'s Naturalizer Danya',3,5,2,1,2500,2250,15,2,'1','images/1h.jpg','images/2h.jpg','images/3h.jpg','images/4h.jpg','images/5h.jpg','images/6h.jpg','normal'),
 (43,'Men\'s Naturalizer Danya',4,4,2,1,6000,4200,25,1,'1','images/1a.jpg','images/2a.jpg','images/3a.jpg','images/4a.jpg','images/5a.jpg','images/6a.jpg','sale');
/*!40000 ALTER TABLE `saleitems` ENABLE KEYS */;


--
-- Definition of table `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `idSales` int(11) NOT NULL AUTO_INCREMENT,
  `Time` varchar(45) DEFAULT NULL,
  `Date` varchar(45) DEFAULT NULL,
  `Quantity` int(10) unsigned DEFAULT NULL,
  `Unit_Price` int(10) unsigned DEFAULT NULL,
  `Discounts` varchar(45) DEFAULT NULL,
  `Customer_idCustomer` int(11) NOT NULL,
  `Month` varchar(45) DEFAULT NULL,
  `Year` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idSales`),
  KEY `fk_Purchases_Customer1` (`Customer_idCustomer`),
  CONSTRAINT `fk_Purchases_Customer10` FOREIGN KEY (`Customer_idCustomer`) REFERENCES `customer` (`idCustomer`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sales`
--

/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;


--
-- Definition of table `saleshoesizeqty`
--

DROP TABLE IF EXISTS `saleshoesizeqty`;
CREATE TABLE `saleshoesizeqty` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shoeid` varchar(45) DEFAULT NULL,
  `size` varchar(45) DEFAULT NULL,
  `qty` int(45) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saleshoesizeqty`
--

/*!40000 ALTER TABLE `saleshoesizeqty` DISABLE KEYS */;
INSERT INTO `saleshoesizeqty` (`id`,`shoeid`,`size`,`qty`) VALUES 
 (24,'4','6',20),
 (25,'5','7',30),
 (26,'6','8',13),
 (28,'43','8',0),
 (31,'38','6',8),
 (32,'38','7',13),
 (33,'38','8',19),
 (35,'43','6',25);
/*!40000 ALTER TABLE `saleshoesizeqty` ENABLE KEYS */;


--
-- Definition of table `session_activities`
--

DROP TABLE IF EXISTS `session_activities`;
CREATE TABLE `session_activities` (
  `idSession_Activities` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(45) DEFAULT NULL,
  `Login_Sessions_idLogin_Sessions` int(11) NOT NULL,
  PRIMARY KEY (`idSession_Activities`),
  KEY `fk_Session_Activities_Login_Sessions1` (`Login_Sessions_idLogin_Sessions`),
  CONSTRAINT `fk_Session_Activities_Login_Sessions1` FOREIGN KEY (`Login_Sessions_idLogin_Sessions`) REFERENCES `login_sessions` (`idLogin_Sessions`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `session_activities`
--

/*!40000 ALTER TABLE `session_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_activities` ENABLE KEYS */;


--
-- Definition of table `shoes`
--

DROP TABLE IF EXISTS `shoes`;
CREATE TABLE `shoes` (
  `idshoes` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `sizes_idsizes` int(11) DEFAULT NULL,
  `colour_idcolour` int(11) DEFAULT NULL,
  `style_idstyle` int(11) DEFAULT NULL,
  `brand_idbrand` int(11) DEFAULT NULL,
  `unti_price` int(10) unsigned DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `gender_idgender` int(11) DEFAULT NULL,
  `common` varchar(45) DEFAULT NULL,
  `image1` varchar(300) DEFAULT NULL,
  `image2` varchar(300) DEFAULT NULL,
  `image3` varchar(300) DEFAULT NULL,
  `image4` varchar(300) DEFAULT NULL,
  `image5` varchar(300) DEFAULT NULL,
  `image6` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`idshoes`),
  KEY `fk_boots_sizes1_idx` (`sizes_idsizes`),
  KEY `fk_boots_colour1_idx` (`colour_idcolour`),
  KEY `fk_boots_style1_idx` (`style_idstyle`),
  KEY `fk_boots_brand1_idx` (`brand_idbrand`),
  KEY `fk_shoes_gender1_idx` (`gender_idgender`),
  CONSTRAINT `fk_boots_brand1` FOREIGN KEY (`brand_idbrand`) REFERENCES `brand` (`idbrand`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boots_colour1` FOREIGN KEY (`colour_idcolour`) REFERENCES `colour` (`idcolour`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boots_sizes1` FOREIGN KEY (`sizes_idsizes`) REFERENCES `sizes` (`idsizes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boots_style1` FOREIGN KEY (`style_idstyle`) REFERENCES `style` (`idstyle`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_shoes_gender1` FOREIGN KEY (`gender_idgender`) REFERENCES `gender` (`idgender`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoes`
--

/*!40000 ALTER TABLE `shoes` DISABLE KEYS */;
INSERT INTO `shoes` (`idshoes`,`name`,`sizes_idsizes`,`colour_idcolour`,`style_idstyle`,`brand_idbrand`,`unti_price`,`qty`,`gender_idgender`,`common`,`image1`,`image2`,`image3`,`image4`,`image5`,`image6`) VALUES 
 (38,'Women\'s Naturalizer Danya',2,10,1,1,4500,44,2,'1','images/1.jpg','images/2.jpg','images/3.jpg','images/4.jpg','images/5.jpg','images/6.jpg'),
 (39,'Women\'s Naturalizer Danya',1,4,1,2,6500,100,2,'1','images/1c.jpg','images/2c.jpg','images/3c.jpg','images/4c.jpg','images/5c.jpg','images/6c.jpg'),
 (40,'Men\'s Naturalizer Danya',4,10,3,1,7500,30,1,'1','images/1g.jpg','images/2g.jpg','images/3g.jpg','images/4g.jpg','images/5g.jpg','images/6g.jpg'),
 (41,'Men\'s Naturalizer Danya',4,4,1,1,4500,25,1,'1','images/1i.jpg','images/2i.jpg','images/3i.jpg','images/4i.jpg','images/5i.jpg','images/6i.jpg'),
 (42,'Women\'s Naturalizer Danya',3,5,2,1,2500,5,2,'1','images/1h.jpg','images/2h.jpg','images/3h.jpg','images/4h.jpg','images/5h.jpg','images/6h.jpg'),
 (43,'Men\'s Naturalizer Danya',4,4,2,1,6000,8,1,'1','images/1a.jpg','images/2a.jpg','images/3a.jpg','images/4a.jpg','images/5a.jpg','images/6a.jpg');
/*!40000 ALTER TABLE `shoes` ENABLE KEYS */;


--
-- Definition of table `shoes_has_images`
--

DROP TABLE IF EXISTS `shoes_has_images`;
CREATE TABLE `shoes_has_images` (
  `id_shoes_has_images` varchar(45) NOT NULL,
  `shoes_idboots` int(11) NOT NULL,
  `images_idimages` int(11) NOT NULL,
  `image` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_shoes_has_images`),
  KEY `fk_shoes_has_images_images1_idx` (`images_idimages`),
  KEY `fk_shoes_has_images_shoes1_idx` (`shoes_idboots`),
  CONSTRAINT `fk_shoes_has_images_shoes1` FOREIGN KEY (`shoes_idboots`) REFERENCES `shoes` (`idshoes`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoes_has_images`
--

/*!40000 ALTER TABLE `shoes_has_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `shoes_has_images` ENABLE KEYS */;


--
-- Definition of table `shoes_has_sizes`
--

DROP TABLE IF EXISTS `shoes_has_sizes`;
CREATE TABLE `shoes_has_sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shoes_idshoes` int(11) NOT NULL,
  `sizes_idsizes` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_shoes_has_sizes_sizes1_idx` (`sizes_idsizes`),
  KEY `fk_shoes_has_sizes_shoes1_idx` (`shoes_idshoes`),
  CONSTRAINT `fk_shoes_has_sizes_shoes1` FOREIGN KEY (`shoes_idshoes`) REFERENCES `shoes` (`idshoes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_shoes_has_sizes_sizes1` FOREIGN KEY (`sizes_idsizes`) REFERENCES `sizes` (`idsizes`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoes_has_sizes`
--

/*!40000 ALTER TABLE `shoes_has_sizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `shoes_has_sizes` ENABLE KEYS */;


--
-- Definition of table `shoesizeqty`
--

DROP TABLE IF EXISTS `shoesizeqty`;
CREATE TABLE `shoesizeqty` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shoeid` varchar(45) DEFAULT '0',
  `size` varchar(45) DEFAULT NULL,
  `qty` int(45) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shoesizeqty`
--

/*!40000 ALTER TABLE `shoesizeqty` DISABLE KEYS */;
INSERT INTO `shoesizeqty` (`id`,`shoeid`,`size`,`qty`) VALUES 
 (78,'39','7',30),
 (79,'40','8',18),
 (80,'41','8',50),
 (81,'42','7',5),
 (85,'7','8',0),
 (86,'4','6',20),
 (87,'42','9',10),
 (88,'7','6',50);
/*!40000 ALTER TABLE `shoesizeqty` ENABLE KEYS */;


--
-- Definition of table `sizes`
--

DROP TABLE IF EXISTS `sizes`;
CREATE TABLE `sizes` (
  `idsizes` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idsizes`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sizes`
--

/*!40000 ALTER TABLE `sizes` DISABLE KEYS */;
INSERT INTO `sizes` (`idsizes`,`size`) VALUES 
 (1,'6'),
 (2,'7'),
 (3,'8'),
 (4,'9'),
 (5,'10'),
 (6,'11'),
 (7,'12'),
 (8,'13'),
 (9,'14'),
 (10,'15');
/*!40000 ALTER TABLE `sizes` ENABLE KEYS */;


--
-- Definition of table `style`
--

DROP TABLE IF EXISTS `style`;
CREATE TABLE `style` (
  `idstyle` int(11) NOT NULL AUTO_INCREMENT,
  `style` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idstyle`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `style`
--

/*!40000 ALTER TABLE `style` DISABLE KEYS */;
INSERT INTO `style` (`idstyle`,`style`) VALUES 
 (1,'OUTDOOR'),
 (2,'DRESS'),
 (3,'CASUAL'),
 (4,'SPORTS'),
 (5,'COMFORT');
/*!40000 ALTER TABLE `style` ENABLE KEYS */;


--
-- Definition of table `sys_interface`
--

DROP TABLE IF EXISTS `sys_interface`;
CREATE TABLE `sys_interface` (
  `idsys_interface` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idsys_interface`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_interface`
--

/*!40000 ALTER TABLE `sys_interface` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_interface` ENABLE KEYS */;


--
-- Definition of table `sys_interface_has_use_case`
--

DROP TABLE IF EXISTS `sys_interface_has_use_case`;
CREATE TABLE `sys_interface_has_use_case` (
  `idcomp` int(11) NOT NULL AUTO_INCREMENT,
  `sys_interface_idsys_interface` int(11) NOT NULL,
  `use_case_iduse_case` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `url` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idcomp`),
  KEY `fk_sys_interface_has_use_case_use_case1_idx` (`use_case_iduse_case`),
  KEY `fk_sys_interface_has_use_case_sys_interface1_idx` (`sys_interface_idsys_interface`),
  CONSTRAINT `fk_sys_interface_has_use_case_sys_interface1` FOREIGN KEY (`sys_interface_idsys_interface`) REFERENCES `sys_interface` (`idsys_interface`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_sys_interface_has_use_case_use_case1` FOREIGN KEY (`use_case_iduse_case`) REFERENCES `use_case` (`iduse_case`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sys_interface_has_use_case`
--

/*!40000 ALTER TABLE `sys_interface_has_use_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_interface_has_use_case` ENABLE KEYS */;


--
-- Definition of table `use_case`
--

DROP TABLE IF EXISTS `use_case`;
CREATE TABLE `use_case` (
  `iduse_case` int(11) NOT NULL AUTO_INCREMENT,
  `use_case_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`iduse_case`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `use_case`
--

/*!40000 ALTER TABLE `use_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `use_case` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `First_Name` varchar(45) DEFAULT NULL,
  `Last_Name` varchar(45) DEFAULT NULL,
  `usertype_idusertype` int(11) DEFAULT NULL,
  `gender` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) NOT NULL,
  `address1` varchar(45) NOT NULL,
  `address2` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `postalcode` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `usertype` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`iduser`),
  KEY `fk_user_usertype` (`usertype_idusertype`),
  CONSTRAINT `fk_user_usertype` FOREIGN KEY (`usertype_idusertype`) REFERENCES `usertype` (`idusertype`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`iduser`,`First_Name`,`Last_Name`,`usertype_idusertype`,`gender`,`email`,`mobile`,`address1`,`address2`,`city`,`postalcode`,`country`,`usertype`,`status`) VALUES 
 (46,'Kaushala','Prabodana',1,'Male','Kaushalaprabodana@gmail.com','0772207500','726/E','Kottunna Road','Heiyanthuduwa','32025','Sri Lanka','1','Active'),
 (56,'Ashani','Indrachapa',2,'Fe-Male','AshaniIndrachapa@gmail.com','0772207500','726/E','Kottunna Road','Heiyanthuduwa','32025','Sri Lanka','2','Active'),
 (57,'Tharindu','Thiwanka',3,'Male','Tharindu@gmail.com','0772207500','777/E','Samurdhi Mawatha','Heiyanthuduwa','32025','USA','3','Active');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Definition of table `user_login`
--

DROP TABLE IF EXISTS `user_login`;
CREATE TABLE `user_login` (
  `idUser_Login` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(45) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `user_iduser` int(11) NOT NULL,
  PRIMARY KEY (`idUser_Login`),
  KEY `fk_User_Login_user1` (`user_iduser`),
  CONSTRAINT `fk_User_Login_user1` FOREIGN KEY (`user_iduser`) REFERENCES `user` (`iduser`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_login`
--

/*!40000 ALTER TABLE `user_login` DISABLE KEYS */;
INSERT INTO `user_login` (`idUser_Login`,`Username`,`Password`,`user_iduser`) VALUES 
 (46,'Kaushala','1234',46),
 (56,'Ash123','123',56),
 (57,'ABC123','12345',57);
/*!40000 ALTER TABLE `user_login` ENABLE KEYS */;


--
-- Definition of table `usertype`
--

DROP TABLE IF EXISTS `usertype`;
CREATE TABLE `usertype` (
  `idusertype` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idusertype`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usertype`
--

/*!40000 ALTER TABLE `usertype` DISABLE KEYS */;
INSERT INTO `usertype` (`idusertype`,`type`) VALUES 
 (1,'Admin'),
 (2,'User'),
 (3,'Customer');
/*!40000 ALTER TABLE `usertype` ENABLE KEYS */;


--
-- Definition of table `usertype_has_use_case`
--

DROP TABLE IF EXISTS `usertype_has_use_case`;
CREATE TABLE `usertype_has_use_case` (
  `id_user_case` int(11) NOT NULL AUTO_INCREMENT,
  `usertype_idusertype` int(11) NOT NULL,
  `use_case_iduse_case` int(11) NOT NULL,
  PRIMARY KEY (`id_user_case`),
  KEY `fk_usertype_has_use_case_use_case1_idx` (`use_case_iduse_case`),
  KEY `fk_usertype_has_use_case_usertype1_idx` (`usertype_idusertype`),
  CONSTRAINT `fk_usertype_has_use_case_usertype1` FOREIGN KEY (`usertype_idusertype`) REFERENCES `usertype` (`idusertype`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_usertype_has_use_case_use_case1` FOREIGN KEY (`use_case_iduse_case`) REFERENCES `use_case` (`iduse_case`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usertype_has_use_case`
--

/*!40000 ALTER TABLE `usertype_has_use_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `usertype_has_use_case` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
