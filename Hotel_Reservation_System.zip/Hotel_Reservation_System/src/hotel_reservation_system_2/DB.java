package hotel_reservation_system_2;


import java.sql.Connection;
import java.sql.DriverManager;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sandeepana amaraseka
 */
public class DB {
   static Connection c;
   public static Connection getcon()throws Exception{
       
       Class.forName("com.mysql.jdbc.Driver");
       c=DriverManager.getConnection("jdbc:mysql://localhost:3306/hms","root","123");
       
      return c;
      
        
        
   }

}
